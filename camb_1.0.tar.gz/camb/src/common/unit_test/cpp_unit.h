#ifndef TESTHARNESS_H__
#define TESTHARNESS_H__

#include "test.h"
#include "test_result.h"
#include "test_failure.h"
#include "test_registry.h"


#endif

